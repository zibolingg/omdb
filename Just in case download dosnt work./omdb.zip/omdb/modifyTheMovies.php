<?php

include_once 'db_credentials.php';
    $link = mysqli_connect('localhost','root','','OMDB');

    if (!$link) {
    echo "Error: Unable to connect to MySQL." . PHP_EOL;
    echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL;
    echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;

}

    if (isset($_POST['submit'])) {
          $native_name_update = $_POST['native_name_update'];
          $english_name_update = $_POST['english_name_update'];
          $year_update = $_POST['year_update'];
          $id = $_POST['id'];

          $query = mysqli_query($link , "UPDATE `movies` SET
          `native_name`='$native_name_update',`english_name`='$english_name_update',`year_made`='$year_update' WHERE movie_id = '$id'");
    }
	header('location: movies.php?updated=Success');
    mysqli_close($link);

?>
