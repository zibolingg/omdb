<div id="menu-left">

<a href="people_people.php">
  	<div <?php if($left_selected == "PEOPLE")
  	{ echo 'class="menu-left-current-page"'; } ?>>
  	<img src="./images/people.png">
  	<br/>People<br/></div>
  </a>


  <a href = "people_trvia.php">
  	<div <?php if($left_selected == "TRIVIA")
  	{ echo 'class="menu-left-current-page"'; } ?>>
  	<img src="./images/trivia.png">
  	<br/>Trivia<br/></div>
  </a>


</div>
