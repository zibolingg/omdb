</div>

</td>
</tr>
</table>

<!-- If we want to add any footer to the web pages, update the footer.-->

<div id="foot"></div>

</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.12/js/jquery.dataTables.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.12/js/dataTables.bootstrap.min.js"></script>

<!-- <script src='ajax/jquery-3.2.1.min.js' type='text/javascript'></script> -->
<script src='ajax/select2/dist/js/select2.min.js' type='text/javascript'></script>
<link href='ajax/select2/dist/css/select2.min.css' rel='stylesheet' type='text/css'>


</body>

</html>
