<?php

// Following four lines set the details to establish a Database connection_aborted
DEFINE('DB_SERVER', 'localhost');
DEFINE('DB_NAME', 'omdb');
DEFINE('DB_USER', 'root');
DEFINE('DB_PASS', '');

?>
